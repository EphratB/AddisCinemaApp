import { save, get, remove } from "./write_to_db";
import { load, loadById } from "./read_from_db";

export { save, get, load, loadById, remove };
