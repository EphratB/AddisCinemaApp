import { useState, useEffect } from "react";
import Nav from "./components/Nav";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { Routes, Route } from "react-router-dom";
import { requests } from "./restapi";
import Movies from "./components/Movies/movies";
import PageNotFound from "./Pages/PageNotFound";
import PageLoader from "./components/PageLoader";
import TvShows from "./Pages/TvShows";
import PopularTvShowsPage from "./Pages/TvShows/PopularTvShowsPage";
import AiringTodayPage from "./Pages/TvShows/AiringTodayPage";
import TopRatedPage from "./Pages/TvShows/TopRatedPage";
import ShowDetailsPage from "./Pages/ShowDetailsPage";
import MyList from "./Pages/MyList";
import * as database from "./database";

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [movies, setSelectedMovies] = useState([]);

  const AddSelectedMovie = (movie) => {
    setSelectedMovies([...movies, movie]);
  };

  useEffect(() => {
    // load the database

    // IIFE immediately Invoked fucntion expression

    (async () => {
      const data = await database.load();
      //console.log("Loading database", data);
      //seting data from database
      setSelectedMovies(data);
      setIsLoading(false);
    })();
  }, []);

  //Remove Task
  const handleRemoveMovies = (id) => {
    const filteredTasks = movies.filter((movie) => movie.id !== id);
    setSelectedMovies(filteredTasks);
  };

  return (
    <div className="app">
      {isLoading ? (
        <PageLoader />
      ) : (
        <Routes>
          <Route
            path="/"
            element={
              <>
                <Nav />
                <Header />
                <Movies handleAddSelectedMovie={AddSelectedMovie} />
                <Footer />
              </>
            }
          />
          <Route
            path="/mylist"
            element={
              <>
                <Nav />
                <Header />
                <MyList movies={movies} onRemoveMovies={handleRemoveMovies} />
                <Footer />
              </>
            }
          />
          <Route
            path="/mylist/:id"
            element={
              <>
                <Nav />
                <Header />
                <ShowDetailsPage />
                <Footer />
              </>
            }
          />
          {/* <Route path="/showdetails/:id" element={<ShowDetailsPage />} /> */}

          <Route
            path="/tvshows"
            element={
              <>
                <Nav />
                <Header />
                <TvShows />
                <Footer />
              </>
            }
          >
            <Route
              path="popular"
              element={
                <PopularTvShowsPage
                  title="Popular TV Shows"
                  fetchUrl={requests.popularTvShows}
                />
              }
            />
            <Route
              path="toprated"
              element={
                <TopRatedPage
                  title="Top Rated TV Shows"
                  fetchUrl={requests.topRated}
                />
              }
            />
            <Route
              path="airingtoday"
              element={
                <AiringTodayPage
                  title="Currently Airing TV Shows"
                  fetchUrl={requests.AirlingToday}
                />
              }
            />
            {/* <Route path="/tvshows/:id" element={<ShowDetailsPage />} /> */}
          </Route>

          <Route
            path="*"
            element={
              <>
                <Nav />
                <PageNotFound />
              </>
            }
          />
        </Routes>
      )}
    </div>
  );
}

export default App;
