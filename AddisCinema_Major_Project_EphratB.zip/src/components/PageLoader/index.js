import React from "react";

function PageLoader({ title }) {
  return (
    <div>
      <h1>Loading...</h1>
    </div>
  );
}

export default PageLoader;
