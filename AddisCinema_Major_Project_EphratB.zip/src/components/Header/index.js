import "./styles.scss";
import Banner from "../Banner";
export default function Header() {
  return <Banner />;
}
