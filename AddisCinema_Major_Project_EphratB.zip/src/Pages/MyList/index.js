import React from "react";
import "./styles.scss";
import { FaCircleNotch } from "react-icons/fa";
import { RiDeleteBinLine } from "react-icons/ri";
import { Link, useNavigate } from "react-router-dom";
import * as database from "../.././database";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function MyList({ movies, onRemoveMovies }) {
  const navigate = useNavigate();

  const imageUrl = `https://image.tmdb.org/t/p/w500`;
  // const [error, setError] = useState("");

  const handleClickImage = (id) => {
    console.log("iddddd", id);
    navigate(`/showdetails/${id}`);
  };

  // remove the movie from the database
  async function handleDelteWatchedMovies(id) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this movie?"
    );

    if (confirmed) {
      // remove from memory
      onRemoveMovies(id);
      const removed = await database.remove(id);

      if (removed) {
        toast.success("Movie deleted successfully!");
      } else {
        toast.error("Failed to delete movie.");
      }
    }
  }

  return (
    <>
      <div className="container">
        <h1>My List</h1>
        {movies && movies.length > 0 ? (
          <div className="movies-container">
            {movies.map((movie, index) => (
              <div className="movie-card" key={index}>
                <Link to={`/mylist/${movie.id}`} key={index}>
                  <img
                    src={`${imageUrl}${movie.poster_path}`}
                    alt={movie.title}
                    onClick={() => handleClickImage(movie.id)}
                  />
                </Link>
                <div className="rating-circle">
                  <FaCircleNotch />
                  <div className="rating-number">{movie.vote_average}</div>
                </div>
                <div className="delete_watched">
                  Watched |{" "}
                  <RiDeleteBinLine
                    onClick={() => {
                      handleDelteWatchedMovies(movie.id);
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="Mylist_text">Your list is empty!</p>
        )}
      </div>
    </>
  );
}

export default MyList;
